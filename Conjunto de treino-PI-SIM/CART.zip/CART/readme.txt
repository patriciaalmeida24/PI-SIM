
1- Install CART128E.exe

2- copy CART.exe to the CART install directory (copy & replace)